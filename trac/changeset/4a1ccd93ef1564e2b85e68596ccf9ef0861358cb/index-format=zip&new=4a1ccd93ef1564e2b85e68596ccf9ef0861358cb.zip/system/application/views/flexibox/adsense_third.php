<div class="ClearFlexiBox Box13<?php if (!empty($last)) echo(' FlexiBoxLast'); ?>">
	<script type="text/javascript">
	<!--
	google_ad_client = "pub-8676956632365960";
	/* 234x60, created 02/06/09 */
	google_ad_slot = "4255960768";
	google_ad_width = 234;
	google_ad_height = 60;
	//-->
	</script>
	<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
</div>