<?php

/**
 * @file controllers/office/whatson.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 */

class Whatson extends Controller
{
	function __construct()
	{
		parent::Controller();
	}

	function index()
	{
		if (!CheckPermissions('editor')) return;

		$this->main_frame->AddMenuItem("what's on", site_url('office/whatson'), true);

		$this->load->model('calendar/whatson_model');
		$calendars = $this->whatson_model->GetAllCalendarsInfo();

		$data = array(
			'Calendars' => $calendars,
		);

		$this->main_frame->SetContentSimple('whatson/office/index', $data);
		$this->main_frame->Load();
	}

	function calendar($shortname = null, $op = null)
	{
		if (!CheckPermissions('editor')) return;

		$this->load->model('calendar/whatson_model');
		if (null === $shortname) {
			show_404();
		}
		else {
			$calendar = $this->whatson_model->GetCalendarInfoByShortName($shortname);
			if (null === $calendar) {
				$this->messages->AddMessage('error', xml_escape("No what's on calendar found with the short name '$shortname'"));
			}
			else {
				$name = $calendar['name'];
				$this->main_frame->AddMenuItem($calendar['name'], site_url('office/whatson'), true);
				switch ($op) {
					case null:
						// show edit page
						$this->_modify($calendar);
						return;
					case 'moveup':
						if ($this->whatson_model->UpdateCalendarOrder($calendar, $calendar['order']-1)) {
							$this->messages->AddMessage('success', xml_escape("Calendar $name successfully moved up"));
						}
						else {
							$this->messages->AddMessage('error', xml_escape("Calendar $name not moved up"));
						}
						break;
					case 'movedown':
						if ($this->whatson_model->UpdateCalendarOrder($calendar, $calendar['order']+1)) {
							$this->messages->AddMessage('success', xml_escape("Calendar $name successfully moved down"));
						}
						else {
							$this->messages->AddMessage('error', xml_escape("Calendar $name not moved down"));
						}
						break;
					case 'manage':
						// Show management calendar
						$this->load->model('calendar/events_model');
						$this->events_model->SetActiveEntityId($calendar['calendar_id'], false, 'vip');

						$this->load->model('subcontrollers/calendar_subcontroller');
						
						$this->calendar_subcontroller->_SetDefault('index');
						
						$permissions = array(
							'create', // Creation of new events
							'edit',   // Editing of owned events
							'index',  // Index (summary) page
						);
						$this->calendar_subcontroller->_AddPermission($permissions);
						
						$sources = & $this->calendar_subcontroller->GetSources();
						$sources->DisableGroup('inactive');
						// restrict to this organisation
						$this->calendar_subcontroller->UseStreams(array(
							(int)$calendar['calendar_id'] => array(
								'subscribed' => true,
								'name' => $calendar['name'],
								'short_name' => $calendar['shortname'],
							)
						));
						
						$args = func_get_args();
						array_shift($args);
						array_shift($args);
						$this->calendar_subcontroller->_map($args);
						return;
					default:
						show_404();
				}
			}
		}

		if (isset($_GET['ret'])) {
			redirect($_GET['ret']);
		}
		redirect('office/whatson');
	}

	// For adding a new what's on calendar
	function add()
	{
		if (!CheckPermissions('editor')) return;

		$this->main_frame->AddMenuItem("what's on", site_url('office/whatson'), true);

		$this->_modify();
	}

	// For editing or adding a what's on calendar
	function _modify($previous_calendar = null, $self_redirect = false)
	{
		if (isset($_POST['cancel'])) {
			// redirect
			if (isset($_GET['ret'])) {
				redirect($_GET['ret']);
			}
			redirect('/office/whatson');
		}
		$get_tail = (isset($_GET['ret']) ? ('?ret='.urlencode($_GET['ret'])) : '');

		$this->load->model('calendar/whatson_model');

		$this->load->helper('input');
		$form = new InputInterfaces;

		$name_interface = new InputTextInterface('name', $previous_calendar['name']);
		$name_interface->SetMaxLength(255);
		$name_interface->SetRequired(true);
		$form->Add('Name', $name_interface);

		$shortname_interface = new InputTextInterface('shortname', $previous_calendar['shortname']);
		$shortname_interface->SetMaxLength(50);
		$shortname_interface->SetRequired(true);
		$shortname_interface->AddValidator(
			new InputTextValidatorRegex(
				'\w+', 'must contain only alphanumeric characters and no spaces'
			)
		);
		$form->Add('Short Name', $shortname_interface);

		$submission_text_interface = new InputTextInterface('submission_text', $previous_calendar['submission_text']);
		$submission_text_interface->SetMaxLength(255);
		$submission_text_interface->SetMultiline(true);
		$form->Add('Submission Text', $submission_text_interface);

		// accepting vip responsibilities
		$user_is_vip = false;
		$default_user_is_vip = true;
		$calendar_id = 0;
		$this->load->model('members_model');
		if (null != $previous_calendar) {
			$calendar_id = $previous_calendar['calendar_id'];
			$full_vips = $this->members_model->GetMemberDetails(
				$previous_calendar['calendar_id'], null,
				'`subscriptions`.`subscription_vip_status`="approved"'
			);
			$user_is_vip = false;
			$default_user_is_vip = false;
			$vips = array();
			foreach ($full_vips as $vip) {
				if ($vip['user_id'] == $this->user_auth->entityId) {
					$user_is_vip = true;
					$default_user_is_vip = true;
				}
				$vips[(int)$vip['user_id']] = $vip;
			}
		}
		else {
			$vips = array();
		}
		$user_is_vip_interface = new InputCheckboxInterface('user_is_vip', $default_user_is_vip);
		$form->Add('I want to accept responsibility for moderating this calendar', $user_is_vip_interface);

		// check form data
		$num_errors = $form->Validate();
		if (0 == $num_errors && $form->Updated() && isset($_POST['save'])) {
			$redirect_target = null;
			$values = ((null === $previous_calendar) ? $form->UpdatedValues() : $form->ChangedValues());
			$totally_no_changes = empty($values);
			unset($values['user_is_vip']);
			if (empty($values)) {
				if ($totally_no_changes) {
					if (!$self_redirect) {
						$this->messages->AddMessage('information', "You didn't make any changes");
					}
				}
			}
			else {
				if (null === $previous_calendar) {
					$result = $this->whatson_model->AddCalendar($values);
					$calendar_id = $result;
					$past_tense_action = 'created';
					if ($result) {
						$redirect_target = 'office/whatson/calendar/'.$values['shortname'].$get_tail;
					}
				}
				else {
					$result = $this->whatson_model->UpdateCalendar($previous_calendar['calendar_id'], $values);
					$past_tense_action = 'edited';
					if ($result && isset($values['shortname'])) {
						$redirect_target = 'office/whatson/calendar/'.$values['shortname'].$get_tail;
					}
				}
				if ($result) {
					$this->messages->AddMessage('success', "Calendar has been $past_tense_action");
				}
				else {
					$this->messages->AddMessage('error', "Calendar could not be $past_tense_action");
				}
			}
			// User VIP status changed?
			if ($calendar_id && $user_is_vip != $user_is_vip_interface->Value()) {
				if ($user_is_vip_interface->Value()) {
					// Add this user as a VIP
					$result = $this->members_model->UpdateVipStatus('approved', $this->user_auth->entityId, $calendar_id);
					if ($result) {
						$this->messages->AddMessage('success', 'Your moderation status was successfully added. You should now receive event submissions to this calendar by email.');
					}
					else {
						$this->messages->AddMessage('error', 'It was not possible to add moderation status to you.');
					}
				}
				else {
					// Remove this user as a VIP
					$result = $this->members_model->UpdateVipStatus('none', $this->user_auth->entityId, $calendar_id);
					if ($result) {
						$this->messages->AddMessage('success', 'Your moderation status was successfully removed. You should no longer receive event submissions to this calendar.');
					}
					else {
						$this->messages->AddMessage('error', 'It was not possible to remove your moderation status.');
					}
				}
				if (null === $redirect_target) {
					unset($_POST['save']);
					return $this->_modify($previous_calendar, true);
				}
			}
			if (null !== $redirect_target) {
				redirect($redirect_target);
			}
		}

		$data = array(
			'Form' => $form,
			'PostAction' => $this->uri->uri_string().$get_tail,
			'Edit' => (null !== $previous_calendar),
			'Vips' => $vips,
		);

		$this->main_frame->SetContentSimple('whatson/office/edit',$data);
		$this->main_frame->Load();
	}
}

?>
