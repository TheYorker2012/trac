<div class="BlueBox">
	<h2>business tools</h2>
	<ul>
		<li><a href="/office/vipmanager">Manage VIPs</a></li>
		<li><a href="/office/advertising">Advertising</a></li>
		<li><a href="/office/prlist">Directory</a></li>
		<li><a href="/office/pr/summary">PR System</a></li>
		<li><a href="/office/whatson">What's On (Event Management)</a></li>
		<li><a href="/office/campaign">Campaigns</a></li>
		<li><a href="/office/charity">Charities</a></li>
		<li><a href="/office/howdoi">How Do I</a></li>
		<li><a href="/office/links">Links</a></li>
		<li><a href="/office/crosswords">Crosswords System</a></li>
	</ul>
</div>
