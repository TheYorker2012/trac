<?php

/**
 * @file views/whatsnew/office/edit.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 *
 * @param $Form        InputInterfaces  Form object.
 * @param $PostAction  string  URI to post data to.
 * @param $Edit        bool  Whether we're editing or adding.
 * @param $Vips        array Vip member details.
 */

$title = ($Edit ? "edit what's on calendar" : "create what's on calendar");

?><div class="BlueBox"><?php

	?><h2><?php echo(xml_escape($title)); ?></h2><?php

	?><form class="form" method="POST" action="<?php echo(xml_escape($PostAction)); ?>"><?php
		?><fieldset><?php
			$Form->Load();
			?><input class="button" type="submit" name="save" value="Save" /><?php
			?><input class="button" type="submit" name="cancel" value="Back" /><?php
		?></fieldset><?php
		?><p>
			Submission text is displayed to organisations wanting to publicise events.
			It should mention what sorts of events the calendar is meant for,
			and any acceptance requirements.
			Leave blank to prevent organisations from submitting events to this calendar.
		</p><?php

	?></form><?php

	?><h2>moderators</h2><?php

	?><p>
		Moderators (also called calendar VIPs) are responsible for accepting
		and rejecting events which are submitted by organisations to the
		calendar.
		When an event is submitted to a calendar and email is sent to each
		moderator to inform them that action is required.
		All calendars which have a submission text can be submitted to, and
		should therefore have at least one moderator so that events do not
		go unnoticed.
	</p><?php

	if (empty($Vips)) {
		?><p><strong>
			Warning: This calendar does not have any moderators and it should.
			Please consider taking on this responsibility.
		</strong></p><?php
	}
	else {
		// vip members
		?><ul><?php
		foreach ($Vips as $vip) {
			?><li><?php
			$is_me = ($vip['user_id'] == $this->user_auth->entityId);
			if ($is_me) {
				?><strong><?php
			}
			echo(xml_escape($vip['firstname'].' '.$vip['surname'].' ('.$vip['username'].')'));
			if ($is_me) {
				?></strong><?php
			}
			?></li><?php
		}
		?></ul><?php
	}

?></div><?php

?>
