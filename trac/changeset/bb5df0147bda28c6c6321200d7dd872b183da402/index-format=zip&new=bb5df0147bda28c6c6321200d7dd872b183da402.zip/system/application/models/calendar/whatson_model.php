<?php

/**
 * @file models/calendar/whatson_model.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 */

class Whatson_model extends Model
{
	function __construct()
	{
		parent::Model();
	}

	/// Get information about all of the what's on calendars.
	/**
	 * @param $organisation_id int,null Organisation id to get whatson list from.
	 *                         uses config[company_entity_id] if null.
	 * @return sorted array[array(name,shortname)]
	 */
	function GetAllCalendarsInfo($organisation_id = null)
	{
		if (null === $organisation_id) {
			$organisation_id = $this->config->item('company_entity_id');
		}
		$sql =
			'SELECT '.
			'	`whatson_calendar_entity_id`		AS `calendar_id`, '.
			'	`whatson_calendar_order`			AS `order`, '.
			'	`organisation_name`					AS `name`, '.
			'	`organisation_directory_entry_name`	AS `shortname` '.
			'FROM `whatson_calendars` '.
			'INNER JOIN `organisations` '.
			'	ON `organisation_entity_id` = `whatson_calendar_entity_id` '.
			'INNER JOIN `organisation_types` '.
			'	ON `organisation_organisation_type_id` = `organisation_type_id` '.
			'WHERE	`whatson_calendar_organisation_entity_id` = ? '.
			'	AND	`organisation_events` = TRUE '.
			'	AND	`organisation_type_codename` = "calendars" '.
			'ORDER BY `whatson_calendar_order` ASC '
			;
		$results = $this->db->query($sql, array($organisation_id))->result_array();
		return $results;
	}

	/// Create a new whatson calendar.
	/**
	 * @param $data array(name,shortname,submission_text) Calendar data.
	 *              submission_text may be null for closed calendars
	 * @param $order int,null Order value. Other order values will be adjusted accordingly.
	 * @param $organisation_id int,null Organisation id to add to whatson list of.
	 *                         uses config[company_entity_id] if null.
	 * @return bool Whether successful
	 */
	function AddCalendar($data, $order = null, $organisation_id = null)
	{
		// process input
		if (null === $organisation_id) {
			$organisation_id = $this->config->item('company_entity_id');
		}
		$data_mapping = array(
			'name' => 'organisation_name',
			'shortname' => 'organisation_directory_entry_name',
			'submission_text' => 'organisation_event_submission_text',
		);
		$sets = array();
		foreach ($data_mapping as $alias => $column) {
			if (isset($data[$alias])) {
				$sets["`$column` = ?"] = $data[$alias];
			}
			else {
				return false;
			}
		}

		// add an entity to get an entity id
		$sql = 'INSERT INTO `entities` () VALUES ()';
		$this->db->query($sql);
		if (!$this->db->affected_rows()) {
			// This shouldn't really ever happen
			return false;
		}
		$entity_id = (int)$this->db->insert_id();

		// add the calendar record to organisations
		$sets["`organisation_entity_id` = ?"] = $entity_id;
		$sets["`organisation_parent_organisation_entity_id` = ?"] = $organisation_id;
		$sets["`organisation_events` = ?"] = true;
		$sql =	'INSERT INTO `organisations` '.
				'SET `organisation_organisation_type_id` = '.
					'('. // find type id of calendars organisation type
						'SELECT	`organisation_type_id` '.
						'FROM	`organisation_types` '.
						'WHERE	`organisation_type_codename` = "calendars" '.
					'), '.
				implode(',',array_keys($sets)).' '.
				'ON DUPLICATE KEY UPDATE `organisation_entity_id`=`organisation_entity_id`'
				;
		$bind = array_values($sets);
		$this->db->query($sql, $bind);
		$success = (bool)$this->db->affected_rows();

		if ($success) {
			if (null === $order) {
				// find the next order
				$sql =	'SELECT MAX(`whatson_calendar_order`) AS max_order '.
						'FROM	`whatson_calendars` '.
						'WHERE	`whatson_calendar_organisation_entity_id` = ? '
						;
				$results = $this->db->query($sql, array($organisation_id))->result_array();
				if (empty($results)) {
					$order = 0;
				}
				else {
					$order = 1 + $results[0]['max_order'];
				}
			}
			else {
				// increment any calendar orders above our desired value.
				$sql =	'UPDATE	`whatson_calendars` '.
						'SET	`whatson_calendar_order` = `whatson_calendar_order` + 1 '.
						'WHERE	`whatson_calendar_organisation_entity_id` = ? '.
						'	AND	`whatson_calendar_order` >= ? '
						;
				$this->db->query($sql, array($organisation_id, $order));
			}

			// add the whatson calendar record
			$sql =	'INSERT INTO `whatson_calendars` '.
					'SET	`whatson_calendar_organisation_entity_id` = ?, '.
					'		`whatson_calendar_order` = ?, '.
					'		`whatson_calendar_entity_id` = ? '
					;
			$this->db->query($sql, array($organisation_id, $order, $entity_id));
			$success = (bool)$this->db->affected_rows();
		}

		// On failure, delete the entity record
		if (!$success) {
			$this->db->query('DELETE FROM `entities` WHERE `entity_id`=?',array($entity_id));
		}

		return $success;
	}
}

?>
