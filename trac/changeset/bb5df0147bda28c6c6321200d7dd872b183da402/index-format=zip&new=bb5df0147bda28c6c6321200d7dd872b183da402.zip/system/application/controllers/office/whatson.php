<?php

/**
 * @file controllers/office/whatson.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 */

class Whatson extends Controller
{
	function __construct()
	{
		parent::Controller();
	}

	function index()
	{
		/*
			show current whatson calendars
		*/
		if (!CheckPermissions('editor')) return;
		$this->load->model('calendar/whatson_model');

		// Load the whats on calendar information
		$info = $this->whatson_model->GetAllCalendarsInfo();

		?><pre><?php
		var_dump($info);
		?></pre><?php

		$this->main_frame->Load();
	}

	function add()
	{
		if (!CheckPermissions('editor')) return;
		$this->load->model('calendar/whatson_model');

		$this->load->helper('input');
		$form = new InputInterfaces;

		$name_interface = new InputTextInterface('name', '');
		$name_interface->SetMaxLength(255);
		$name_interface->SetRequired(true);
		$form->Add('Name', $name_interface);

		$shortname_interface = new InputTextInterface('shortname', '');
		$shortname_interface->SetMaxLength(50);
		$shortname_interface->SetRequired(true);
		$shortname_interface->AddValidator(
			new InputTextValidatorRegex(
				'\w+', 'must contain only alphanumeric characters and no spaces'
			)
		);
		$form->Add('Short Name', $shortname_interface);

		$submission_text_interface = new InputTextInterface('submission_text', '');
		$submission_text_interface->SetMaxLength(255);
		$submission_text_interface->SetMultiline(true);
		$form->Add('Submission Text', $submission_text_interface);

		// check form data
		$num_errors = $form->Validate();
		if (0 == $num_errors) {
			$values = $form->ChangedValues();
			if (!empty($values)) {
				$result = $this->whatson_model->AddCalendar($values);
				if ($result) {
					$this->messages->AddMessage('success', 'Calendar has been created');
					// redirect
					if (isset($_GET['ret'])) {
						redirect($_GET['ret']);
					}
					redirect('/office/whatson');
				}
				else {
					$this->messages->AddMessage('error', 'Calendar could not be created');
				}
			}
		}

		$data = array(
			'Form' => $form,
			'PostAction' => $this->uri->uri_string().(isset($_GET['ret']) ? ('?ret='.urlencode($_GET['ret'])) : ''),
			'Edit' => false,
		);

		$this->main_frame->SetContentSimple('whatson/office/edit',$data);
		$this->main_frame->Load();
	}
}

?>
