<?php

/**
 * @file controllers/whatson.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 */

/// What's on main controller.
class Whatson extends Controller
{
	function __construct()
	{
		parent::Controller();
	}

	function index()
	{
		if (!CheckPermissions('public')) return;

		$this->load->model('calendar/whatson_model');
		$calendars = $this->whatson_model->GetAllCalendarsInfo();

		$boxes = array();
		foreach ($calendars as $id => $info) {
			$boxes[] = array(
				'type'			=>	'whatson_list',
				'title'			=>	'upcoming '.$info['name'],
				'title_link'	=>	'#',
				'size'			=>	'1/3',
				'last'			=>	($id % 3) == 2,
			);
		}

		$data = array(
			'boxes'	=>	$boxes
		);

		$this->main_frame->SetData('menu_tab', "what's on");
		$this->main_frame->SetContentSimple('flexibox/layout', $data);
		$this->main_frame->IncludeCss('stylesheets/home.css');
		$this->main_frame->Load();
	}
}

?>
