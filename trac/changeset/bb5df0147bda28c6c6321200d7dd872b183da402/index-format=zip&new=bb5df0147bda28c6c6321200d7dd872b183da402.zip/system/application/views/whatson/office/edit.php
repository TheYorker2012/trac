<?php

/**
 * @file views/whatsnew/office/edit.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 *
 * @param $Form        InputInterfaces  Form object.
 * @param $PostAction  string  URI to post data to.
 * @param $Edit        bool  Whether we're editing or adding.
 */

?><div class="BlueBox"><?php

	?><h2>create what's on calendar</h2><?php

	?><form class="form" method="POST" action="<?php echo(xml_escape($PostAction)); ?>"><?php
		?><fieldset><?php
			$Form->Load();
			?><input class="button" type="submit" value="Save" /><?php
		?></fieldset><?php
		?><p>
			Submission text is displayed to organisations wanting to publicise events.
			It should mention what sorts of events the calendar is meant for,
			and any acceptance requirements.
			Leave blank to prevent organisations from submitting events to this calendar.
		</p><?php
	?></form><?php

?></div><?php

?>
