<div class="BlueBox">
	<h2>admin tools</h2>
	<ul>
		<li><a href="/office/announcements">Announcements</a></li>
		<li><a href="/office/manage/members">Manage Yorker Members</a></li>
		<li><a href="/admin/permissions">Permissions</a></li>
		<li><a href="/office/moderator">Comment Moderation</a></li>
		<li><a href="/admin/pages">Page Properties</a></li>
		<li><a href="/admin/feedback">Feedback</a></li>
		<li><a href="/office/stats">Statistics</a></li>
		<li><a href="/office/articletypes">Article Types</a></li>
		<li><a href="/office/specials">Special Articles</a></li>
		<li><a href="/office/ticker">Facebook Articles</a></li>
		<li><a href="/office/polls">Polls</a></li>
		<li><a href="/office/podcasts">Podcasts</a></li>
		<li><a href="/office/reviewlist/foodreviews">Food Reviews</a></li>
		<li><a href="/office/reviewlist/drinkreviews">Drink Reviews</a></li>
		<li><a href="/office/reviewtags">Review Tags</a></li>
		<li><a href="/office/leagues">Review Leagues</a></li>
		<li><a href="/office/howdoi">How Do I</a></li>
		<li><a href="/office/games">Game Zone</a></li>
		<li><a href="/office/photos">Photo Requests</a></li>
		<li><a href="/office/banners">Homepage Banners</a></li>
		<li><a href="/office/quotes">Quotes</a></li>
		<li><a href="/office/links">Links</a></li>
		<li><a href="/office/guide">Style Guide</a></li>
	</ul>

	<h2>developer tools</h2>
	<ul>
		<li><a href="/admin/useradmin/edit">Edit User Information</a></li>
		<li><a href="/office/contactus">Edit contact us address'</a></li>
		<li><a href="/admin/feedback">Feedback (<?php echo $feedback_count; ?> entries)</a></li>
		<li><a href="/admin/pages">Page properties, custom pages, etc.</a></li>
		<li><a href="/admin/dev">Webserver information</a></li>
		<li><a href="/admin/imagecp">Image Management</a></li>
	</ul>
</div>
