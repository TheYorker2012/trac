<?php

/**
 * @file controllers/whatson.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 */

/// What's on main controller.
class Whatson extends Controller
{
	private $mainSource = null;

	function __construct()
	{
		parent::Controller();
	}

	function _remap($shortname = null)
	{
		if (!CheckPermissions('public')) return;

		$this->load->model('calendar/whatson_model');
		if (null === $shortname) {
			$calendars = $this->whatson_model->GetAllCalendarsInfo();
		}
		else {
			$calendar = $this->whatson_model->GetCalendarInfoByShortName($shortname);
			if (null === $calendar) {
				$this->messages->AddMessage('error', xml_escape("No what's on calendar found with the short name '$shortname'"));
				redirect('whatson');
			}
			else {
				$calendars = array($calendar);
			}
		}

		$this->_setupMyCalendar();
		$this->mainSource->SetRange(strtotime('today'), strtotime('6month'));

		$boxes = array();
		foreach ($calendars as $id => $info) {
			$boxes[] = array(
				'type'			=>	'whatson_list',
				'title'			=>	'upcoming '.$info['name'],
				'title_link'	=>	site_url('whatson/'.$info['shortname']),
				'size'			=>	(null !== $shortname ? '1' : '1/3'),
				'last'			=>	($id % 3) == 2,
				'CalendarId'    =>  $info['calendar_id'],
				'MaxEvents'     =>  (null !== $shortname ? 100 : 3),
				'PadEvents'     =>  (null !== $shortname ? 1 : 3),
				'ReturnUri'     =>  (null !== $shortname ? site_url('whatson') : null)
			);
			$this->mainSource->GetSource(0)->IncludeStream($info['calendar_id'], TRUE);
		}
		// Get the events
		$calendar_data = new CalendarData();
		$this->messages->AddMessages($this->mainSource->FetchEvents($calendar_data));
		
		$data = array(
			'boxes'	=>	$boxes,
			'CalendarData' => &$calendar_data,
		);

		$this->pages_model->SetPageCode('whatson_index');
		$this->main_frame->SetData('menu_tab', "what's on");
		$this->main_frame->SetContentSimple('flexibox/layout', $data);
		$this->main_frame->IncludeCss('stylesheets/home.css');
		$this->main_frame->Load();
	}

	/// Setup the main source.
	function _SetupMyCalendar()
	{
		if (null === $this->mainSource) {
			$this->load->library('calendar_backend');
			$this->load->library('calendar_source_my_calendar');
			
			$this->mainSource = new CalendarSourceMyCalendar();

			$this->mainSource->DisableGroup('subscribed');
			$this->mainSource->DisableGroup('owned');
			$this->mainSource->DisableGroup('private');
			$this->mainSource->EnableGroup('active');
			$this->mainSource->DisableGroup('inactive');
			$this->mainSource->EnableGroup('hide');
			$this->mainSource->EnableGroup('show');
			$this->mainSource->EnableGroup('rsvp');
		}
		return $this->mainSource;
	}
}

?>
