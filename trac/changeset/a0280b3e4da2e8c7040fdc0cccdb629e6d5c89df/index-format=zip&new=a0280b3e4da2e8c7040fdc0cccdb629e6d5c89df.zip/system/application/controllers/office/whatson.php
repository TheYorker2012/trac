<?php

/**
 * @file controllers/office/whatson.php
 * @author James Hogan <james_hogan@theyorker.co.uk>
 */

class Whatson extends Controller
{
	function __construct()
	{
		parent::Controller();
	}

	function index()
	{
		if (!CheckPermissions('editor')) return;

		$this->main_frame->AddMenuItem("what's on", site_url('office/whatson'), true);

		$this->load->model('calendar/whatson_model');
		$calendars = $this->whatson_model->GetAllCalendarsInfo();

		$data = array(
			'Calendars' => $calendars,
		);

		$this->main_frame->SetContentSimple('whatson/office/index', $data);
		$this->main_frame->Load();
	}

	function calendar($shortname = null, $op = null)
	{
		if (!CheckPermissions('editor')) return;

		$this->load->model('calendar/whatson_model');
		if (null === $shortname) {
			show_404();
		}
		else {
			$calendar = $this->whatson_model->GetCalendarInfoByShortName($shortname);
			if (null === $calendar) {
				$this->messages->AddMessage('error', xml_escape("No what's on calendar found with the short name '$shortname'"));
			}
			else {
				$name = $calendar['name'];
				$this->main_frame->AddMenuItem($calendar['name'], site_url('office/whatson'), true);
				switch ($op) {
					case null:
						// show edit page
						$this->_modify($calendar);
						return;
					case 'moveup':
						if ($this->whatson_model->UpdateCalendarOrder($calendar, $calendar['order']-1)) {
							$this->messages->AddMessage('success', xml_escape("Calendar $name successfully moved up"));
						}
						else {
							$this->messages->AddMessage('error', xml_escape("Calendar $name not moved up"));
						}
						break;
					case 'movedown':
						if ($this->whatson_model->UpdateCalendarOrder($calendar, $calendar['order']+1)) {
							$this->messages->AddMessage('success', xml_escape("Calendar $name successfully moved down"));
						}
						else {
							$this->messages->AddMessage('error', xml_escape("Calendar $name not moved down"));
						}
						break;
					case 'manage':
						// Show management calendar
						$this->load->model('calendar/events_model');
						$this->events_model->SetActiveEntityId($calendar['calendar_id'], false, 'vip');

						$this->load->model('subcontrollers/calendar_subcontroller');
						
						$this->calendar_subcontroller->_SetDefault('index');
						
						$permissions = array(
							'create', // Creation of new events
							'edit',   // Editing of owned events
							'index',  // Index (summary) page
						);
						$this->calendar_subcontroller->_AddPermission($permissions);
						
						$sources = & $this->calendar_subcontroller->GetSources();
						$sources->DisableGroup('inactive');
						// restrict to this organisation
						$this->calendar_subcontroller->UseStreams(array(
							(int)$calendar['calendar_id'] => array(
								'subscribed' => true,
								'name' => $calendar['name'],
								'short_name' => $calendar['shortname'],
							)
						));
						
						$args = func_get_args();
						array_shift($args);
						array_shift($args);
						$this->calendar_subcontroller->_map($args);
						return;
					default:
						show_404();
				}
			}
		}

		if (isset($_GET['ret'])) {
			redirect($_GET['ret']);
		}
		redirect('office/whatson');
	}

	// For adding a new what's on calendar
	function add()
	{
		if (!CheckPermissions('editor')) return;

		$this->main_frame->AddMenuItem("what's on", site_url('office/whatson'), true);

		$this->_modify();
	}

	// For editing or adding a what's on calendar
	function _modify($previous_calendar = null)
	{
		$this->load->model('calendar/whatson_model');

		$this->load->helper('input');
		$form = new InputInterfaces;

		$name_interface = new InputTextInterface('name', $previous_calendar['name']);
		$name_interface->SetMaxLength(255);
		$name_interface->SetRequired(true);
		$form->Add('Name', $name_interface);

		$shortname_interface = new InputTextInterface('shortname', $previous_calendar['shortname']);
		$shortname_interface->SetMaxLength(50);
		$shortname_interface->SetRequired(true);
		$shortname_interface->AddValidator(
			new InputTextValidatorRegex(
				'\w+', 'must contain only alphanumeric characters and no spaces'
			)
		);
		$form->Add('Short Name', $shortname_interface);

		$submission_text_interface = new InputTextInterface('submission_text', $previous_calendar['submission_text']);
		$submission_text_interface->SetMaxLength(255);
		$submission_text_interface->SetMultiline(true);
		$form->Add('Submission Text', $submission_text_interface);

		// check form data
		$num_errors = $form->Validate();
		if (0 == $num_errors && $form->Updated()) {
			$values = $form->ChangedValues();
			if (empty($values)) {
				$this->messages->AddMessage('information', "You didn't make any changes");
			}
			else {
				if (null === $previous_calendar) {
					$result = $this->whatson_model->AddCalendar($values);
					$past_tense_action = 'created';
				}
				else {
					$result = $this->whatson_model->UpdateCalendar($previous_calendar['calendar_id'], $values);
					$past_tense_action = 'edited';
				}
				if ($result) {
					$this->messages->AddMessage('success', "Calendar has been $past_tense_action");
					// redirect
					if (isset($_GET['ret'])) {
						redirect($_GET['ret']);
					}
					redirect('/office/whatson');
				}
				else {
					$this->messages->AddMessage('error', "Calendar could not be $past_tense_action");
				}
			}
		}

		$data = array(
			'Form' => $form,
			'PostAction' => $this->uri->uri_string().(isset($_GET['ret']) ? ('?ret='.urlencode($_GET['ret'])) : ''),
			'Edit' => (null !== $previous_calendar),
		);

		$this->main_frame->SetContentSimple('whatson/office/edit',$data);
		$this->main_frame->Load();
	}
}

?>
