<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file Frame_office.php
 * @author James Hogan (jh559@cs.york.ac.uk)
 * @brief Extension of public frame.
 */

// Load the Frames library
$CI = &get_instance();
$CI->load->library('frame_public');
$CI->load->model('permissions_model');

/// Main office frame library class.
class Frame_office extends Frame_public
{
	/// disable adverts for the office frame
	protected $mHasAdverts = FALSE;
	
	/// Default constructor.
	function __construct()
	{
		parent::__construct();
		$this->SetView('frames/office_frame.php');
		$this->SetData('menu', array(
			array('home', '/office', array()),
			array('articles', '/office/articles', array()),
			array('gallery', '/office/gallery', array()),
			array('business', '/office/business', array()),
			array('admin', '/admin', array())
		));
	}

	function AddMenuItem($label, $link, $select = false)
	{
		$this->mDataArray['menu'][] = array($label, $link, array());
		if ($select) {
			$this->SetData('menu_tab', $label);
		}
	}

	function Load()
	{
		$this->mDataArray['menu'][0][2][] = 'first';
		$this->mDataArray['menu'][count($this->mDataArray['menu'])-1][2][] = 'last';
		parent::Load();
	}
}

?>
